<?php
require __DIR__ . '/vendor/autoload.php';

use setasign\Fpdi\Fpdi;

// initiate FPDI
$pdf = new Fpdi();
$pdf->AddPage('L'); // adds page in landscape
$pdf->setSourceFile("template.pdf");
// import page 1
$tplId = $pdf->importPage(1);
// use the imported page and place it at point 5,5 with your preferred width in mm
$pdf->useTemplate($tplId, 0, 0, 298);
$pdf->SetFont('Arial','',50); // Font Name, Font Style (eg. 'B' for Bold), Font Size
$pdf->SetTextColor(231,105,110); // RGB
$pdf->SetXY(16, 110); // X start, Y start in mm
$text = "Andrew Thomas";
$pdf->Write(0, $text);


// adds current date
$pdf->SetFont('Arial','',12); 
$pdf->SetTextColor(0,0,0); 
$pdf->SetXY(17, 175); 
$date = date('F dS, Y');
$pdf->Write(0, $date);

$pdf->Output();

?>